# Skin Coconut

This is a skin for my children to use to watch the old classics we've ripped as easily as watching shows on Prime/Netflix.

The goals to strip this addon down to just listing TV shows in a nice way with simple text descriptions and thumbnails. Ratings, links to other shows, etc. will slowly get ripped out.

See installation notes below

This is based on Skin TITAN BINGIE

# Terms of use
With the installation of the skin you agree that you don't use it in combination with blacklisted and illegal Kodi add-ons. I'm not associated with any available build and I won't give any support to blacklisted, banned or illegal third party addons.

# License
This work has been released under GNU General Public License v2.0.

# IMPORTANT NOTE FOR USERS
Install the skin through the official coconut repository for updates and the supported addons required!
The content here is for developing purposes!
https://github.com/cocorepo/repository.coconut
